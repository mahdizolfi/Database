﻿namespace WindowsFormsApp5
{
    partial class Frm_Dashboardcs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.studentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.teacherToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.courceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.stCoruceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tchCourceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.teacherToolStripMenuItem,
            this.courceToolStripMenuItem,
            this.stCoruceToolStripMenuItem,
            this.tchCourceToolStripMenuItem,
            this.studentToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(706, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(97, 24);
            this.toolStripMenuItem1.Text = "افزودن افراد";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // studentToolStripMenuItem
            // 
            this.studentToolStripMenuItem.Name = "studentToolStripMenuItem";
            this.studentToolStripMenuItem.Size = new System.Drawing.Size(134, 24);
            this.studentToolStripMenuItem.Text = "افزودن دانش آموز";
            this.studentToolStripMenuItem.Click += new System.EventHandler(this.studentToolStripMenuItem_Click);
            // 
            // teacherToolStripMenuItem
            // 
            this.teacherToolStripMenuItem.Name = "teacherToolStripMenuItem";
            this.teacherToolStripMenuItem.Size = new System.Drawing.Size(108, 24);
            this.teacherToolStripMenuItem.Text = "افزودن مدرس";
            this.teacherToolStripMenuItem.Click += new System.EventHandler(this.teacherToolStripMenuItem_Click);
            // 
            // courceToolStripMenuItem
            // 
            this.courceToolStripMenuItem.Name = "courceToolStripMenuItem";
            this.courceToolStripMenuItem.Size = new System.Drawing.Size(99, 24);
            this.courceToolStripMenuItem.Text = "افزودن درس";
            this.courceToolStripMenuItem.Click += new System.EventHandler(this.courceToolStripMenuItem_Click);
            // 
            // stCoruceToolStripMenuItem
            // 
            this.stCoruceToolStripMenuItem.Name = "stCoruceToolStripMenuItem";
            this.stCoruceToolStripMenuItem.Size = new System.Drawing.Size(150, 24);
            this.stCoruceToolStripMenuItem.Text = "افزودن درس دانشجو";
            this.stCoruceToolStripMenuItem.Click += new System.EventHandler(this.stCoruceToolStripMenuItem_Click);
            // 
            // tchCourceToolStripMenuItem
            // 
            this.tchCourceToolStripMenuItem.Name = "tchCourceToolStripMenuItem";
            this.tchCourceToolStripMenuItem.Size = new System.Drawing.Size(143, 24);
            this.tchCourceToolStripMenuItem.Text = "افزودن درس مدرس";
            this.tchCourceToolStripMenuItem.Click += new System.EventHandler(this.tchCourceToolStripMenuItem_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::WindowsFormsApp5.Properties.Resources._1200px_STVC_svg;
            this.pictureBox1.Location = new System.Drawing.Point(90, 42);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(440, 378);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // Frm_Dashboardcs
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(706, 451);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Frm_Dashboardcs";
            this.Text = "سامانه دانشگاه";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem studentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem teacherToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem courceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem stCoruceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tchCourceToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApp5
{
    public partial class Frm_st_cd : Form
    {
        public Frm_st_cd()
        {
            InitializeComponent();
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            dbEntities db = new dbEntities();
           tbl_st_cd fr = new tbl_st_cd();
            fr.Fk_student = cmb_student.SelectedValue.ToString();
            fr.Fk_Cource = cmb_cource.SelectedValue.ToString();
            db.tbl_st_cd.Add(fr);
            db.SaveChanges();
            MessageBox.Show("عملیات با موفقیت انجام شد ");


            grid.DataSource = db.tbl_st_cd.ToList();
            grid.Refresh();
        }

        private void btn_show_Click(object sender, EventArgs e)
        {
           
            dbEntities db = new dbEntities();
            grid.DataSource = db.tbl_st_cd.ToList();
            grid.Refresh();
        }

        private void Frm_st_cd_Load(object sender, EventArgs e)
        {
            dbEntities db = new dbEntities();
            var list = db.tbl_person.ToList();
            cmb_student.DataSource = list;
            cmb_student.DisplayMember = "Family";
            cmb_student.ValueMember = "Family";

            var list2 = db.tbl_cource.ToList();
            cmb_cource.DataSource = list2;
            cmb_cource.DisplayMember = "Name";
            cmb_cource.ValueMember = "Name";
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApp5
{
    public partial class Frm_tch_cd : Form
    {
        public Frm_tch_cd()
        {
            InitializeComponent();
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            dbEntities db = new dbEntities();
            tbl_tch_cd fr = new tbl_tch_cd();
            fr.Fk_teacher = cmb_teacher.SelectedValue.ToString();
            fr.Fk_Cource = cmb_cource.SelectedValue.ToString();
            db.tbl_tch_cd.Add(fr);
            db.SaveChanges();
            MessageBox.Show("عملیات با موفقیت انجام شد ");

            grid.DataSource = db.tbl_tch_cd.ToList();
            grid.Refresh();
        }

        private void btn_show_Click(object sender, EventArgs e)
        {
            dbEntities db = new dbEntities();
            grid.DataSource = db.tbl_tch_cd.ToList();
            grid.Refresh();
        }

        private void Frm_tch_cd_Load(object sender, EventArgs e)
        {
            dbEntities db = new dbEntities();
            var list = db.tbl_teacher.ToList();
            cmb_teacher.DataSource = list;
            cmb_teacher.DisplayMember = "Family";
            cmb_teacher.ValueMember = "Family";

            var list2 = db.tbl_cource.ToList();
            cmb_cource.DataSource = list2;
            cmb_cource.DisplayMember = "Name";
            cmb_cource.ValueMember = "Name";
        }
    }
}

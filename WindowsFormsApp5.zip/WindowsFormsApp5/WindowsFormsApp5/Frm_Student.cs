﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApp5
{
    public partial class Frm_Student : Form
    {
        public Frm_Student()
        {
            InitializeComponent();
        }

        private void Frm_Student_Load(object sender, EventArgs e)
        {
            dbEntities db = new dbEntities();
            var list = db.tbl_person.ToList();
            cmb_person.DataSource = list;
            cmb_person.DisplayMember = "Family";
            cmb_person.ValueMember = "Family";
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            dbEntities db = new dbEntities();
            tbl_student st = new tbl_student();
            st.Fk_person = cmb_person.SelectedValue.ToString();
            st.shomareh = txt_shomareh.Text;
            db.tbl_student.Add(st);
            db.SaveChanges();

            MessageBox.Show("عملیات با موفقیت انجام شد ");


            grid.DataSource = db.tbl_student.ToList();
            grid.Refresh();
        }

        private void btn_show_Click(object sender, EventArgs e)
        {
            dbEntities db = new dbEntities();
            grid.DataSource = db.tbl_student.ToList();
            grid.Refresh();
        }
    }
}

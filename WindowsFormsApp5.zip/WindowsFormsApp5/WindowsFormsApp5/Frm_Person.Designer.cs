﻿namespace WindowsFormsApp5
{
    partial class Frm_Person
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.l_Family = new System.Windows.Forms.Label();
            this.l_Jensiat = new System.Windows.Forms.Label();
            this.l_sen = new System.Windows.Forms.Label();
            this.txt_Name = new System.Windows.Forms.TextBox();
            this.txt_family = new System.Windows.Forms.TextBox();
            this.txt_jensiat = new System.Windows.Forms.TextBox();
            this.txt_sen = new System.Windows.Forms.TextBox();
            this.txt_password = new System.Windows.Forms.TextBox();
            this.l_Password = new System.Windows.Forms.Label();
            this.btn_add = new System.Windows.Forms.Button();
            this.grid = new System.Windows.Forms.DataGridView();
            this.btn_show = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.grid)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(34, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(19, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "نام";
            // 
            // l_Family
            // 
            this.l_Family.AutoSize = true;
            this.l_Family.Location = new System.Drawing.Point(232, 12);
            this.l_Family.Name = "l_Family";
            this.l_Family.Size = new System.Drawing.Size(65, 17);
            this.l_Family.TabIndex = 1;
            this.l_Family.Text = "نام خانوادگی";
            // 
            // l_Jensiat
            // 
            this.l_Jensiat.AutoSize = true;
            this.l_Jensiat.Location = new System.Drawing.Point(438, 15);
            this.l_Jensiat.Name = "l_Jensiat";
            this.l_Jensiat.Size = new System.Drawing.Size(40, 17);
            this.l_Jensiat.TabIndex = 2;
            this.l_Jensiat.Text = "جنسیت";
            // 
            // l_sen
            // 
            this.l_sen.AutoSize = true;
            this.l_sen.Location = new System.Drawing.Point(34, 52);
            this.l_sen.Name = "l_sen";
            this.l_sen.Size = new System.Drawing.Size(23, 17);
            this.l_sen.TabIndex = 3;
            this.l_sen.Text = "سن";
            // 
            // txt_Name
            // 
            this.txt_Name.Location = new System.Drawing.Point(109, 12);
            this.txt_Name.Name = "txt_Name";
            this.txt_Name.Size = new System.Drawing.Size(100, 22);
            this.txt_Name.TabIndex = 4;
            // 
            // txt_family
            // 
            this.txt_family.Location = new System.Drawing.Point(307, 12);
            this.txt_family.Name = "txt_family";
            this.txt_family.Size = new System.Drawing.Size(108, 22);
            this.txt_family.TabIndex = 5;
            // 
            // txt_jensiat
            // 
            this.txt_jensiat.Location = new System.Drawing.Point(513, 10);
            this.txt_jensiat.Name = "txt_jensiat";
            this.txt_jensiat.Size = new System.Drawing.Size(100, 22);
            this.txt_jensiat.TabIndex = 6;
            // 
            // txt_sen
            // 
            this.txt_sen.Location = new System.Drawing.Point(109, 49);
            this.txt_sen.Name = "txt_sen";
            this.txt_sen.Size = new System.Drawing.Size(100, 22);
            this.txt_sen.TabIndex = 7;
            // 
            // txt_password
            // 
            this.txt_password.Location = new System.Drawing.Point(307, 48);
            this.txt_password.Name = "txt_password";
            this.txt_password.Size = new System.Drawing.Size(108, 22);
            this.txt_password.TabIndex = 9;
            // 
            // l_Password
            // 
            this.l_Password.AutoSize = true;
            this.l_Password.Location = new System.Drawing.Point(232, 51);
            this.l_Password.Name = "l_Password";
            this.l_Password.Size = new System.Drawing.Size(55, 17);
            this.l_Password.TabIndex = 8;
            this.l_Password.Text = "رمز عبور";
            // 
            // btn_add
            // 
            this.btn_add.Location = new System.Drawing.Point(629, 6);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(91, 34);
            this.btn_add.TabIndex = 10;
            this.btn_add.Text = "اضافه کردن";
            this.btn_add.UseVisualStyleBackColor = true;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // grid
            // 
            this.grid.AllowUserToAddRows = false;
            this.grid.AllowUserToDeleteRows = false;
            this.grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grid.Location = new System.Drawing.Point(12, 88);
            this.grid.Name = "grid";
            this.grid.ReadOnly = true;
            this.grid.RowTemplate.Height = 24;
            this.grid.Size = new System.Drawing.Size(718, 284);
            this.grid.TabIndex = 11;
            // 
            // btn_show
            // 
            this.btn_show.Location = new System.Drawing.Point(629, 48);
            this.btn_show.Name = "btn_show";
            this.btn_show.Size = new System.Drawing.Size(91, 34);
            this.btn_show.TabIndex = 12;
            this.btn_show.Text = "نمایش اطلاعات";
            this.btn_show.UseVisualStyleBackColor = true;
            this.btn_show.Click += new System.EventHandler(this.btn_show_Click);
            // 
            // Frm_Person
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(740, 385);
            this.Controls.Add(this.btn_show);
            this.Controls.Add(this.grid);
            this.Controls.Add(this.btn_add);
            this.Controls.Add(this.txt_password);
            this.Controls.Add(this.l_Password);
            this.Controls.Add(this.txt_sen);
            this.Controls.Add(this.txt_jensiat);
            this.Controls.Add(this.txt_family);
            this.Controls.Add(this.txt_Name);
            this.Controls.Add(this.l_sen);
            this.Controls.Add(this.l_Jensiat);
            this.Controls.Add(this.l_Family);
            this.Controls.Add(this.label1);
            this.Name = "Frm_Person";
            this.Text = "اضافه کردن افراد";
            ((System.ComponentModel.ISupportInitialize)(this.grid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label l_Family;
        private System.Windows.Forms.Label l_Jensiat;
        private System.Windows.Forms.Label l_sen;
        private System.Windows.Forms.TextBox txt_Name;
        private System.Windows.Forms.TextBox txt_family;
        private System.Windows.Forms.TextBox txt_jensiat;
        private System.Windows.Forms.TextBox txt_sen;
        private System.Windows.Forms.TextBox txt_password;
        private System.Windows.Forms.Label l_Password;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.DataGridView grid;
        private System.Windows.Forms.Button btn_show;
    }
}
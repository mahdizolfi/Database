﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApp5
{
    public partial class Frm_Login : Form
    {
        public Frm_Login()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(txt_username.Text == "admin" && txt_Pass.Text == "admin")
            {
               
                Frm_Dashboardcs frm = new Frm_Dashboardcs();
                frm.Show();

            }
            else
            {
                MessageBox.Show("نام کاربری یا گذرواژه مطابقت ندارد");
            }
        }
    }
}

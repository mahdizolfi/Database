﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApp5
{
    public partial class Frm_Cource : Form
    {
        public Frm_Cource()
        {
            InitializeComponent();
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            dbEntities db = new dbEntities();
            tbl_cource cd = new tbl_cource();
            cd.Name = txt_Name.Text;
            cd.Vahed = txt_vahed.Text;
            db.tbl_cource.Add(cd);
            db.SaveChanges();

            MessageBox.Show("عملیات با موفقیت انجام شد ");


            grid.DataSource = db.tbl_cource.ToList();
            grid.Refresh();
        }

        private void btn_show_Click(object sender, EventArgs e)
        {
            dbEntities db = new dbEntities();
            grid.DataSource = db.tbl_cource.ToList();
            grid.Refresh();
        }
    }
}

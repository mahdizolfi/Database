﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApp5
{
    public partial class Frm_Dashboardcs : Form
    {
        public Frm_Dashboardcs()
        {
            InitializeComponent();
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Frm_Person frm = new Frm_Person();
            frm.Show();

        }

        private void studentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Frm_Student frm = new Frm_Student();
            frm.Show();

        }

        private void teacherToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Frm_Teacher frm = new Frm_Teacher();
            frm.Show();

        }

        private void courceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Frm_Cource frm = new Frm_Cource();
            frm.Show();
        }

        private void tchCourceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Frm_tch_cd fr = new Frm_tch_cd();
            fr.Show();

        }

        private void stCoruceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Frm_st_cd fr = new Frm_st_cd();
            fr.Show();
        }
    }
}

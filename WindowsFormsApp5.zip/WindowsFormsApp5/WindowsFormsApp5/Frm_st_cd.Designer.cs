﻿namespace WindowsFormsApp5
{
    partial class Frm_st_cd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmb_student = new System.Windows.Forms.ComboBox();
            this.btn_show = new System.Windows.Forms.Button();
            this.grid = new System.Windows.Forms.DataGridView();
            this.btn_add = new System.Windows.Forms.Button();
            this.l_Family = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.cmb_cource = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.grid)).BeginInit();
            this.SuspendLayout();
            // 
            // cmb_student
            // 
            this.cmb_student.FormattingEnabled = true;
            this.cmb_student.Location = new System.Drawing.Point(82, 16);
            this.cmb_student.Name = "cmb_student";
            this.cmb_student.Size = new System.Drawing.Size(121, 24);
            this.cmb_student.TabIndex = 33;
            // 
            // btn_show
            // 
            this.btn_show.Location = new System.Drawing.Point(632, 10);
            this.btn_show.Name = "btn_show";
            this.btn_show.Size = new System.Drawing.Size(75, 34);
            this.btn_show.TabIndex = 32;
            this.btn_show.Text = "نمایش اطلاعات";
            this.btn_show.UseVisualStyleBackColor = true;
            this.btn_show.Click += new System.EventHandler(this.btn_show_Click);
            // 
            // grid
            // 
            this.grid.AllowUserToAddRows = false;
            this.grid.AllowUserToDeleteRows = false;
            this.grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grid.Location = new System.Drawing.Point(12, 63);
            this.grid.Name = "grid";
            this.grid.ReadOnly = true;
            this.grid.RowTemplate.Height = 24;
            this.grid.Size = new System.Drawing.Size(718, 284);
            this.grid.TabIndex = 31;
            // 
            // btn_add
            // 
            this.btn_add.Location = new System.Drawing.Point(440, 10);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(75, 34);
            this.btn_add.TabIndex = 30;
            this.btn_add.Text = "اضافه کردن";
            this.btn_add.UseVisualStyleBackColor = true;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // l_Family
            // 
            this.l_Family.AutoSize = true;
            this.l_Family.Location = new System.Drawing.Point(239, 16);
            this.l_Family.Name = "l_Family";
            this.l_Family.Size = new System.Drawing.Size(47, 17);
            this.l_Family.TabIndex = 28;
            this.l_Family.Text = "نام درس";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(23, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 17);
            this.label1.TabIndex = 27;
            this.label1.Text = "نام دانشجو";
            // 
            // cmb_cource
            // 
            this.cmb_cource.FormattingEnabled = true;
            this.cmb_cource.Location = new System.Drawing.Point(296, 16);
            this.cmb_cource.Name = "cmb_cource";
            this.cmb_cource.Size = new System.Drawing.Size(121, 24);
            this.cmb_cource.TabIndex = 34;
            // 
            // Frm_st_cd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(739, 362);
            this.Controls.Add(this.cmb_cource);
            this.Controls.Add(this.cmb_student);
            this.Controls.Add(this.btn_show);
            this.Controls.Add(this.grid);
            this.Controls.Add(this.btn_add);
            this.Controls.Add(this.l_Family);
            this.Controls.Add(this.label1);
            this.Name = "Frm_st_cd";
            this.Text = "اضافه کردن درس دانشجو";
            this.Load += new System.EventHandler(this.Frm_st_cd_Load);
            ((System.ComponentModel.ISupportInitialize)(this.grid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmb_student;
        private System.Windows.Forms.Button btn_show;
        private System.Windows.Forms.DataGridView grid;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.Label l_Family;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmb_cource;
    }
}
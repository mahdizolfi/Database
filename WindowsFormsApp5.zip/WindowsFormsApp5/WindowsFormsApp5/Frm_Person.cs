﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApp5
{
    public partial class Frm_Person : Form
    {
        public Frm_Person()
        {
            InitializeComponent();
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            dbEntities db = new dbEntities();
            tbl_person tb = new tbl_person();
            tb.Name = txt_Name.Text;
            tb.Family = txt_family.Text;
            tb.Jensiat = txt_jensiat.Text;
            tb.Sen = txt_sen.Text;
            tb.Password = txt_password.Text;
            db.tbl_person.Add(tb);
            db.SaveChanges();
            MessageBox.Show("عملیات با موفقیت انجام شد ");

           
            grid.DataSource = db.tbl_person.ToList();
            grid.Refresh();

        }

        private void btn_show_Click(object sender, EventArgs e)
        {
            dbEntities db = new dbEntities();
            grid.DataSource = db.tbl_person.ToList();
            grid.Refresh();
        }
    }
}
